import logo from './logo.svg';
import './App.css';
import Welcome from './Welcome';
import StateUpdate from './StateUpdate';
import EmployeeDetails from './Employee';
import Emp from './Emp';

function App() {
  return (
    <div className="App">
      <h2>React Application</h2>
      <Welcome fname='Swati'/>
      <EmployeeDetails/>
      <Emp/>
      <StateUpdate/>
    </div>
  );
}

export default App;
