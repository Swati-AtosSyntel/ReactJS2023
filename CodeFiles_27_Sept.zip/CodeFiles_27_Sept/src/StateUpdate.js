import React from 'react';

class StateUpdate extends React.Component{
    constructor(props){
        super();
        this.state={num:0};
        this.updateNumber=this.updateNumber.bind(this);
    }
    updateNumber(){
        this.setState({num:50})
    }
    render(){
        return(
            <div>
            <h3>{this.state.num}</h3>
            <button onClick={this.updateNumber}>Click Here</button>
            </div>
        )
    }
}
export default StateUpdate;