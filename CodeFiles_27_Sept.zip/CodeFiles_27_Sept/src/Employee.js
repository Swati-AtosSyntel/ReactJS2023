import React from 'react';
class EmployeeDetails extends React.Component{
    constructor(){
        super();
        this.state={EmpId:1,Ename:'Swati'}

    }
    render(){
        return(
            <div>
                <Employee eid={this.state.EmpId} ename={this.state.Ename}/>
            {/* <h2>Employee ID: {this.state.EmpId}</h2>
            <h2>Employee Name: {this.state.Ename}</h2> */}
            </div>
        )
    }
}
class Employee extends React.Component{
render(){
    return(
    <div>
        <h3>Employee Details</h3>
        <h2>Employee Id: {this.props.eid}</h2>
        <h2>Employee Name: {this.props.ename}</h2>
    </div>)
}
}
export default EmployeeDetails;