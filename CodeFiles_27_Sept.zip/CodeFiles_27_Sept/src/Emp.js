import React from 'react';
class Emp extends React.Component{
    constructor(){
        super();
        this.state={emps:[{EmpId:1,Ename:'Swati'},
        {EmpId:2,Ename:'Amol'},
        {EmpId:3,Ename:'Amar'},
        {EmpId:4,Ename:'Nitesh'},
        {EmpId:5,Ename:'Sumeet'}

    ]}

    }
    render(){
        return(
            <div>
                <table border="1">
                    <tr>
                        <th>Employee ID</th>
                        <th>Employee Name</th>
                        </tr>
                        <tbody>
                    {this.state.emps.map((e)=><TableRow employee={e}/>)}
                    </tbody>
                </table>
            </div>
        )
    }
}
class TableRow extends React.Component{
    render(){
        return(
            <tr>
                <td>{this.props.employee.EmpId}</td>
                <td>{this.props.employee.Ename}</td>
            </tr>
        )
    }
}
export default Emp;