import React from 'react';
// function Welcome(props){
//     return(
//         <h3>{props.fname}</h3>
//     )
// }
class Welcome extends React.Component{
    render(){
        return(
            <h3>Welcome {this.props.fname}</h3>
        )
    }
}
export default Welcome;